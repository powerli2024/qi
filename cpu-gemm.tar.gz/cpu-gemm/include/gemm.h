#ifndef GEMM_H_
#define GEMM_H_

void gemm(const float* A, const float* B, float* C, int M, int N, int K);

#endif  // GEMM_H_
