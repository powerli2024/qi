#!/bin/bash

set -euo pipefail

CASE_FILE="data/cases.in"
readonly CASE_FILE

if [[ ! -f "$CASE_FILE" ]]; then
  echo "case file not found: $CASE_FILE" >&2
  exit 1
fi

make
./gemm_bench "$CASE_FILE"
