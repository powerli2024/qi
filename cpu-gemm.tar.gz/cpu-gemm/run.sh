#!/bin/bash
set -euo pipefail

CASE_FILE="data/cases.in"
readonly CASE_FILE

if [[ ! -f "$CASE_FILE" ]]; then
  echo "case file not found: $CASE_FILE" >&2
  exit 1
fi

make

# 设置 OpenMP 线程数（评测平台最多 16 核）
export OMP_NUM_THREADS=16
# 绑定线程到核心，减少调度开销
export KMP_AFFINITY=compact

./gemm_bench "$CASE_FILE"