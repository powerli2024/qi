#include "gemm.h"
#include <immintrin.h>
#include <cstdlib>

#define MC 256
#define NC 1024
#define KC 512
#define MR 4
#define NR 16

static inline void micro_kernel_4x16_full(
    const float* A,
    const float* packed_B,
    float* C,
    int KC,
    int N,
    int row,
    int col,
    int k_offset,
    int K
) {
    __m512 c0 = _mm512_loadu_ps(&C[row * N + col]);
    __m512 c1 = _mm512_loadu_ps(&C[(row+1) * N + col]);
    __m512 c2 = _mm512_loadu_ps(&C[(row+2) * N + col]);
    __m512 c3 = _mm512_loadu_ps(&C[(row+3) * N + col]);
    
    for (int k = 0; k < KC; ++k) {
        __m512 a0 = _mm512_set1_ps(A[(row+0) * K + k_offset + k]);
        __m512 a1 = _mm512_set1_ps(A[(row+1) * K + k_offset + k]);
        __m512 a2 = _mm512_set1_ps(A[(row+2) * K + k_offset + k]);
        __m512 a3 = _mm512_set1_ps(A[(row+3) * K + k_offset + k]);
        
        __m512 b = _mm512_load_ps(&packed_B[k * NR]);
        
        c0 = _mm512_fmadd_ps(a0, b, c0);
        c1 = _mm512_fmadd_ps(a1, b, c1);
        c2 = _mm512_fmadd_ps(a2, b, c2);
        c3 = _mm512_fmadd_ps(a3, b, c3);
    }
    
    _mm512_storeu_ps(&C[row * N + col], c0);
    _mm512_storeu_ps(&C[(row+1) * N + col], c1);
    _mm512_storeu_ps(&C[(row+2) * N + col], c2);
    _mm512_storeu_ps(&C[(row+3) * N + col], c3);
}

static inline void micro_kernel_general(
    const float* A,
    const float* packed_B,
    float* C,
    int mr,
    int nr,
    int KC,
    int N,
    int row,
    int col,
    int k_offset,
    int K
) {
    float c[4][16] = {{0}};
    
    for (int k = 0; k < KC; ++k) {
        for (int i = 0; i < mr; ++i) {
            float a = A[(row + i) * K + k_offset + k];
            for (int j = 0; j < nr; ++j) {
                c[i][j] += a * packed_B[k * nr + j];
            }
        }
    }
    
    for (int i = 0; i < mr; ++i) {
        for (int j = 0; j < nr; ++j) {
            C[(row + i) * N + (col + j)] += c[i][j];
        }
    }
}

void gemm(const float* A, const float* B, float* C, int M, int N, int K) {
    for (int ic = 0; ic < M; ic += MC) {
        int mc = (ic + MC > M) ? M - ic : MC;
        
        for (int jc = 0; jc < N; jc += NC) {
            int nc = (jc + NC > N) ? N - jc : NC;
            
            float* packed_B = (float*)aligned_alloc(64, KC * nc * sizeof(float));
            if (!packed_B) continue;
            
            for (int kc = 0; kc < K; kc += KC) {
                int kc_size = (kc + KC > K) ? K - kc : KC;
                
                for (int k = 0; k < kc_size; ++k) {
                    for (int j = 0; j < nc; ++j) {
                        packed_B[k * nc + j] = B[(kc + k) * N + (jc + j)];
                    }
                }
                
                for (int i = ic; i < ic + mc; i += MR) {
                    int mr = (i + MR > ic + mc) ? (ic + mc - i) : MR;
                    
                    for (int j = 0; j < nc; j += NR) {
                        int nr = (j + NR > nc) ? (nc - j) : NR;
                        
                        if (mr == 4 && nr == 16) {
                            micro_kernel_4x16_full(A, packed_B, C, 
                                                    kc_size, N, 
                                                    i, jc + j, kc, K);
                        } else {
                            micro_kernel_general(A, packed_B, C, 
                                                  mr, nr, kc_size, N,
                                                  i, jc + j, kc, K);
                        }
                    }
                }
            }
            free(packed_B);
        }
    }
}