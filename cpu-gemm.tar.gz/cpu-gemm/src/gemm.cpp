#include "gemm.h"
#include <immintrin.h>
#include <cstdlib>
#include <cstring>

#define MC 384
#define NC 4096
#define KC 256
#define MR 4
#define NR 16

#define THRESHOLD 100000

static void naive_gemm(const float* A, const float* B, float* C, int M, int N, int K) {
    for (int i = 0; i < M; ++i) {
        for (int k = 0; k < K; ++k) {
            float a = A[i * K + k];
            float* c_row = C + i * N;
            const float* b_row = B + k * N;
            for (int j = 0; j < N; ++j) {
                c_row[j] += a * b_row[j];
            }
        }
    }
}

static inline void micro_kernel_4x16(
    const float* A,
    const float* packed_B,
    float* C,
    int kc,
    int nc,
    int N,
    int row,
    int col,
    int j_offset,
    int k_offset,
    int K)
{
    __m512 c0 = _mm512_loadu_ps(&C[(row+0) * N + col]);
    __m512 c1 = _mm512_loadu_ps(&C[(row+1) * N + col]);
    __m512 c2 = _mm512_loadu_ps(&C[(row+2) * N + col]);
    __m512 c3 = _mm512_loadu_ps(&C[(row+3) * N + col]);

    for (int k = 0; k < kc; ++k) {
        __m512 a0 = _mm512_set1_ps(A[(row+0) * K + k_offset + k]);
        __m512 a1 = _mm512_set1_ps(A[(row+1) * K + k_offset + k]);
        __m512 a2 = _mm512_set1_ps(A[(row+2) * K + k_offset + k]);
        __m512 a3 = _mm512_set1_ps(A[(row+3) * K + k_offset + k]);

        __m512 b = _mm512_loadu_ps(&packed_B[k * nc + j_offset]);

        c0 = _mm512_fmadd_ps(a0, b, c0);
        c1 = _mm512_fmadd_ps(a1, b, c1);
        c2 = _mm512_fmadd_ps(a2, b, c2);
        c3 = _mm512_fmadd_ps(a3, b, c3);
    }

    _mm512_storeu_ps(&C[(row+0) * N + col], c0);
    _mm512_storeu_ps(&C[(row+1) * N + col], c1);
    _mm512_storeu_ps(&C[(row+2) * N + col], c2);
    _mm512_storeu_ps(&C[(row+3) * N + col], c3);
}

static inline void micro_kernel_general(
    const float* A,
    const float* packed_B,
    float* C,
    int mr, int nr,
    int kc, int nc,
    int N,
    int row, int col,
    int j_offset,
    int k_offset,
    int K)
{
    float c[4][16] = {{0}};
    for (int k = 0; k < kc; ++k) {
        for (int i = 0; i < mr; ++i) {
            float a = A[(row+i) * K + k_offset + k];
            for (int j = 0; j < nr; ++j) {
                c[i][j] += a * packed_B[k * nc + (j_offset + j)];
            }
        }
    }
    for (int i = 0; i < mr; ++i) {
        for (int j = 0; j < nr; ++j) {
            C[(row+i) * N + (col+j)] += c[i][j];
        }
    }
}

void gemm(const float* A, const float* B, float* C, int M, int N, int K) {
    if ((size_t)M * N * K < THRESHOLD) {
        naive_gemm(A, B, C, M, N, K);
        return;
    }

    #pragma omp parallel for schedule(dynamic)
    for (int ic = 0; ic < M; ic += MC) {
        int mc = (ic + MC > M) ? M - ic : MC;
        for (int jc = 0; jc < N; jc += NC) {
            int nc = (jc + NC > N) ? N - jc : NC;

            float* packed_B = (float*)aligned_alloc(64, KC * nc * sizeof(float));
            if (!packed_B) continue;

            for (int kc = 0; kc < K; kc += KC) {
                int kc_size = (kc + KC > K) ? K - kc : KC;

                for (int k = 0; k < kc_size; ++k) {
                    const float* b_row = B + (kc + k) * N + jc;
                    float* pb_row = packed_B + k * nc;
                    memcpy(pb_row, b_row, nc * sizeof(float));
                }

                for (int i = ic; i < ic + mc; i += MR) {
                    int mr = (i + MR > ic + mc) ? (ic + mc - i) : MR;
                    for (int j = 0; j < nc; j += NR) {
                        int nr = (j + NR > nc) ? (nc - j) : NR;
                        if (mr == 4 && nr == 16) {
                            micro_kernel_4x16(A, packed_B, C,
                                              kc_size, nc, N,
                                              i, jc + j, j, kc, K);
                        } else {
                            micro_kernel_general(A, packed_B, C,
                                                 mr, nr, kc_size, nc, N,
                                                 i, jc + j, j, kc, K);
                        }
                    }
                }
            }
            free(packed_B);
        }
    }
}