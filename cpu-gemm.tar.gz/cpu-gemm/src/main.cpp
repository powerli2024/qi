#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <vector>

#include "../include/gemm.h"

namespace {

constexpr float kAbsTolerance = 1e-3f;
constexpr std::uint32_t kRandomSeed = 20260318u;
constexpr double kCorrectnessScoreFull = 20.0;
constexpr double kPerformanceScoreFull = 80.0;

struct GemmCase {
  int M;
  int N;
  int K;
};

struct ScorePolicy {
  const char* name;
  double weight;
  double speedup_90;
  double speedup_full;
};

constexpr ScorePolicy kSmallPolicy{"small", 5.0, 10.0, 10.0};
constexpr ScorePolicy kMediumPolicy{"medium", 20.0, 150.0, 300.0};
constexpr ScorePolicy kLargePolicy{"large", 30.0, 300.0, 1000.0};

struct CaseResult {
  GemmCase test_case;
  const ScorePolicy* policy;
  double ref_ms;
  double impl_ms;
  double speedup;
  double raw_score;
  double weighted_performance_score;
  double case_percent_score;
  float max_abs_error;
  bool ok;
};

void ref_gemm(const float* A, const float* B, float* C, int M, int N, int K) {
  for (int i = 0; i < M; ++i) {
    for (int j = 0; j < N; ++j) {
      float sum = C[i * N + j];
      for (int k = 0; k < K; ++k) {
        sum += A[i * K + k] * B[k * N + j];
      }
      C[i * N + j] = sum;
    }
  }
}

double run_once(void (*kernel)(const float*, const float*, float*, int, int, int),
                const std::vector<float>& A,
                const std::vector<float>& B,
                const std::vector<float>& C_init,
                std::vector<float>* C_out,
                int M,
                int N,
                int K) {
  *C_out = C_init;
  const auto start = std::chrono::high_resolution_clock::now();
  kernel(A.data(), B.data(), C_out->data(), M, N, K);
  const auto end = std::chrono::high_resolution_clock::now();
  return std::chrono::duration<double, std::milli>(end - start).count();
}

float max_abs_error(const std::vector<float>& actual,
                    const std::vector<float>& expected) {
  float max_error = 0.0f;
  for (std::size_t i = 0; i < actual.size(); ++i) {
    max_error = std::max(max_error, std::fabs(actual[i] - expected[i]));
  }
  return max_error;
}

const ScorePolicy& classify_case(const GemmCase& test_case) {
  const int max_dim = std::max(test_case.M, std::max(test_case.N, test_case.K));
  if (max_dim <= 128) {
    return kSmallPolicy;
  }
  if (max_dim <= 512) {
    return kMediumPolicy;
  }
  return kLargePolicy;
}

double score_from_speedup(double speedup, const ScorePolicy& policy) {
  if (speedup <= 1.0) {
    return 0.0;
  }
  if (policy.speedup_full <= policy.speedup_90) {
    return policy.weight * std::min(speedup / policy.speedup_full, 1.0);
  }
  if (speedup < policy.speedup_90) {
    return policy.weight * 0.9 * (speedup - 1.0) / (policy.speedup_90 - 1.0);
  }
  if (speedup < policy.speedup_full) {
    const double upper_range = policy.speedup_full - policy.speedup_90;
    return policy.weight *
           (0.9 + 0.1 * (speedup - policy.speedup_90) / upper_range);
  }
  return policy.weight;
}

bool load_cases_from_file(const std::string& path, std::vector<GemmCase>* cases) {
  std::ifstream fin(path);
  if (!fin) {
    std::cerr << "failed to open case file: " << path << '\n';
    return false;
  }

  std::string line;
  int line_no = 0;
  while (std::getline(fin, line)) {
    ++line_no;
    if (line.empty()) {
      continue;
    }
    if (line[0] == '#') {
      continue;
    }

    std::istringstream iss(line);
    GemmCase test_case{};
    std::string extra_token;
    if (!(iss >> test_case.M >> test_case.N >> test_case.K) || (iss >> extra_token)) {
      std::cerr << "invalid case line " << line_no << ": " << line << '\n';
      return false;
    }
    cases->push_back(test_case);
  }

  if (cases->empty()) {
    std::cerr << "no valid cases found in: " << path << '\n';
    return false;
  }
  return true;
}

CaseResult run_case(const GemmCase& test_case) {
  const int M = test_case.M;
  const int N = test_case.N;
  const int K = test_case.K;

  std::mt19937 rng(
      kRandomSeed ^ static_cast<std::uint32_t>(M * 1315423911u + N * 2654435761u + K));
  std::uniform_real_distribution<float> dist(-1.0f, 1.0f);

  std::vector<float> A(static_cast<std::size_t>(M) * K);
  std::vector<float> B(static_cast<std::size_t>(K) * N);
  std::vector<float> C_init(static_cast<std::size_t>(M) * N);
  for (float& x : A) {
    x = dist(rng);
  }
  for (float& x : B) {
    x = dist(rng);
  }
  for (float& x : C_init) {
    x = dist(rng);
  }

  std::vector<float> C_ref;
  std::vector<float> C_test;

  const double ref_ms = run_once(ref_gemm, A, B, C_init, &C_ref, M, N, K);
  const double impl_ms = run_once(gemm, A, B, C_init, &C_test, M, N, K);
  const float error = max_abs_error(C_test, C_ref);
  const bool ok = error <= kAbsTolerance;
  const double speedup = impl_ms > 0.0 ? ref_ms / impl_ms : 0.0;
  const ScorePolicy& policy = classify_case(test_case);
  const double raw_score = ok ? score_from_speedup(speedup, policy) : 0.0;

  return CaseResult{
      test_case, &policy, ref_ms, impl_ms, speedup, raw_score, 0.0, 0.0, error, ok};
}

double total_raw_weight(const std::vector<CaseResult>& results) {
  double total = 0.0;
  for (const CaseResult& result : results) {
    total += result.policy->weight;
  }
  return total;
}

void normalize_scores(std::vector<CaseResult>* results) {
  const double raw_total = total_raw_weight(*results);
  if (raw_total <= 0.0) {
    return;
  }
  for (CaseResult& result : *results) {
    result.weighted_performance_score =
        kPerformanceScoreFull * result.raw_score / raw_total;
    result.case_percent_score =
        result.policy->weight > 0.0 ? 100.0 * result.raw_score / result.policy->weight : 0.0;
  }
}

void print_case_result(const CaseResult& result,
                       std::size_t index,
                       std::size_t total) {
  const double case_correctness_score = result.ok ? kCorrectnessScoreFull : 0.0;
  const double case_total_score =
      case_correctness_score + result.weighted_performance_score;

  std::cout << "==> Case " << index << "/" << total << '\n';
  std::cout << "shape      : M=" << result.test_case.M
            << ", N=" << result.test_case.N
            << ", K=" << result.test_case.K << '\n';
  std::cout << "category   : " << result.policy->name
            << " (weight=" << result.policy->weight
            << ", 90%@" << result.policy->speedup_90 << "x"
            << ", full@" << result.policy->speedup_full << "x)\n";
  std::cout << "max error  : " << result.max_abs_error << '\n';
  std::cout << "ref time   : " << result.ref_ms << " ms\n";
  std::cout << "impl time  : " << result.impl_ms << " ms\n";
  std::cout << "speedup    : " << result.speedup << "x\n";
  std::cout << "scores     : perf " << result.case_percent_score
            << " / 100.000, correctness " << case_correctness_score
            << " / 40.000, total " << case_total_score << " / 100.000\n";
  std::cout << "Weighted total score " << case_total_score * result.policy->weight / 100.0
            << " / " << result.policy->weight << '\n';
  std::cout << std::endl;
}

void print_summary(const std::vector<CaseResult>& results) {
  double total_ref_ms = 0.0;
  double total_impl_ms = 0.0;
  double performance_score = 0.0;
  bool all_ok = true;

  for (const CaseResult& result : results) {
    total_ref_ms += result.ref_ms;
    total_impl_ms += result.impl_ms;
    performance_score += result.weighted_performance_score;
    all_ok = all_ok && result.ok;
  }

  const double correctness_score = all_ok ? kCorrectnessScoreFull : 0.0;
  const double total_score = correctness_score + performance_score;

  std::cout << "==> Summary\n";
  std::cout << "cases             : " << results.size() << '\n';
  std::cout << "total ref time    : " << total_ref_ms << " ms\n";
  std::cout << "total impl time   : " << total_impl_ms << " ms\n";
  if (total_impl_ms > 0.0) {
    std::cout << "overall speedup   : " << (total_ref_ms / total_impl_ms) << "x\n";
  }
  std::cout << "correctness score : " << correctness_score
            << " / " << kCorrectnessScoreFull << '\n';
  std::cout << "performance score : " << performance_score
            << " / " << kPerformanceScoreFull << '\n';
  std::cout << "total score       : " << total_score << " / 100.000\n";
}

void print_usage(const char* program) {
  std::cerr << "usage:\n";
  std::cerr << "  " << program << " M N K\n";
  std::cerr << "  " << program << " CASE_FILE\n";
}

}  // namespace

int main(int argc, char** argv) {
  std::cout << std::fixed << std::setprecision(3);

  std::vector<GemmCase> cases;
  if (argc == 4) {
    cases.push_back(GemmCase{std::atoi(argv[1]), std::atoi(argv[2]), std::atoi(argv[3])});
  } else if (argc == 2) {
    if (!load_cases_from_file(argv[1], &cases)) {
      return 1;
    }
  } else {
    print_usage(argv[0]);
    return 1;
  }

  std::vector<CaseResult> results;
  results.reserve(cases.size());
  for (const GemmCase& test_case : cases) {
    results.push_back(run_case(test_case));
  }

  normalize_scores(&results);
  for (std::size_t i = 0; i < results.size(); ++i) {
    print_case_result(results[i], i + 1, results.size());
  }

  for (const CaseResult& result : results) {
    if (!result.ok) {
      std::cerr << "correctness check failed\n";
      return 1;
    }
  }

  print_summary(results);
  return 0;
}
